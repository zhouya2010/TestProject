CREATE FUNCTION `query_area`(`areaId` VARCHAR(20))
  RETURNS VARCHAR(64)
BEGIN
	DECLARE parentId INT;
	DECLARE temp VARCHAR(100);
	DECLARE res VARCHAR(100);
	
	SET parentId = 0;
	SET temp = areaId;
	SET res = '';

	SELECT parent,district INTO parentId, temp FROM t_nation WHERE FIND_IN_SET(temp,code);

	WHILE parentId > 0
	DO
		SET res = CONCAT(temp,res);
		SELECT parent,district INTO parentId, temp FROM t_nation WHERE FIND_IN_SET(parentId,id);
	END WHILE;
	RETURN res;
END